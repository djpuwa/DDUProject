import Navbar from "./Navbar1";


const FeesHead = () => {
  return <div className="title"><Navbar/></div>;
};

export default FeesHead;
