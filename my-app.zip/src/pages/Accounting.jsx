import Navbar from "./Navbar1";

const Accounting = () => {
  return <div className="title"> <Navbar/></div>;
};

export default Accounting;
