import Navbar from "./Navbar1";


const Saved = () => {
  return <div className="title"><Navbar/></div>;
};

export default Saved;
