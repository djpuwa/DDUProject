
import Navbar from "./Navbar1";

const Registrar = () => {
  return <div className="title"><Navbar/>
 
  
  </div>;
};

export default Registrar;
