import React from 'react';
import bgimg from "./../../imges/bg.jpg";
import Navbar from "./Navbar1";

const HomePage = () => {
   
  return (
    
      <div  style={{ backgroundImage: `url(${bgimg})` }} className="home">
          <button onClick={this.HomePage}>login</button>
          <Navbar/>
      </div>

  )
}

export default HomePage
