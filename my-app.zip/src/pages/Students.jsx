import SideBar from "../components/Sidebar";
import Navbar from "./Navbar1";

const Students = () => {
  return <div className="title">
    <SideBar />
  </div>;
};

export default Students;
