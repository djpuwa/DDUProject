import Navbar from "./Navbar1";



const SubjectMaster = () => {
  return <div className="title"> <Navbar/></div>;
};

export default SubjectMaster;
