import Navbar from "./Navbar1";



const Examination = () => {
  return <div className="title"><Navbar/></div>;
};

export default Examination;