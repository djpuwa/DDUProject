import Navbar from "./Navbar1";



const Analytics = () => {
  return <div className="title"><Navbar/></div>;
};

export default Analytics;
